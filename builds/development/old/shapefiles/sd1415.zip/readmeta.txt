*******************************************************************************
A NOTE ON METADATA FORMATS FOR THIS DATA SET:

In addition to the .html version of the metadata for this data set, the 
.xml version is also included. 

* The .html version is provided for viewing.
* The .xml version is a generic format that can be edited with metadata 
editing tools.

The .xml is provided for the convenience of the data user who would 
like to document changes they have made to the original data set. MnGeo 
recommends that if you change the data file, you rename it and create a new 
metadata record with the new data set name, to avoid confusion between the 
user-revised data set and the original.

For help with metadata, go to 
http://www.mngeo.state.mn.us/chouse/meta.html or email gisinfo.mngeo@state.mn.us

*******************************************************************************
